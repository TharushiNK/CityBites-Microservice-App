package com.example.freshmart_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FreshmartUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
