package com.example.freshmart_user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreshmartUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreshmartUserApplication.class, args);
	}

}
